//! Configuration types

pub mod opaque;
